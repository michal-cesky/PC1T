#pragma once

int prunik(double zacatek1, double konec1, double zacatek2, double konec2, double* vysl_zacatek, double* vysl_konec);
void rozdil(double zacatek1, double konec1, double zacatek2, double konec2);