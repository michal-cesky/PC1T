#include <iostream>
#include <ctype.h>

int main()
{
	int pocetZnaku = 0;
	char aktualniZnak = NULL;
	char predchoziZnak = NULL;
	int pocetCisel = 0;
	int pocetPismen = 0;
	int pocetSlov = 0;

	FILE* f;
	fopen_s(&f, "vstup.txt", "r");

	while (!feof(f))
	{
		aktualniZnak = getc(f);
		printf("%c", aktualniZnak);
		//kod pro vypocty

		if (isdigit(aktualniZnak))
		{
			pocetCisel++;
		}

		if (isalpha(aktualniZnak))
		{
			pocetPismen++;
		}

		if (isspace(aktualniZnak) && isalpha(predchoziZnak) || predchoziZnak == ',')
		{
			pocetSlov++;

		}

		predchoziZnak = aktualniZnak;
		pocetZnaku++;
	}

	fclose(f);

	fopen_s(&f, "vystup.txt", "w");
	fprintf(f, "Pocet znaku: %d\n", pocetZnaku);
	fprintf(f, "Pocet cislic: %d\n", pocetCisel);
	fprintf(f, "Pocet pismen: %d\n", pocetPismen);
	fprintf(f, "Pocet SLOV: %d\n", pocetSlov);
	fclose(f);

	printf("\nPocet znaku: %d \n", pocetZnaku);
	printf("Pocet Cisel: %d \n", pocetCisel);
	printf("Pocet Pismen: %d \n", pocetPismen);
	printf("Pocet Slov: %d \n", pocetSlov);

	return 0;
}