#pragma once


int indexNejblizsi(int velikost, int(*poleBodu)[2], int referencniX, int
	referencniY);
double prumernaVzdalenost(int velikost, int(*poleBodu)[2], int referencniX, int
	referencniY);

